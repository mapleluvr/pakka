import{a as e}from"./shared-VLOOLVTS.js";import"./shared-DZSZYJLX.js";export{e as createStaticSource};
