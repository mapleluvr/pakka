import{a as t}from"./shared-UNWTQGQX.js";var e=t("BottomSheetEscapeContext",1,!0);e.displayName="BottomSheetEscapeContext";export{e as a};
