import{a as o,b as r,c as l}from"./shared-QTKYRAFZ.js";import"./shared-DZSZYJLX.js";export{l as scrollEventTarget,r as scrollportTop,o as scrollsPage};
