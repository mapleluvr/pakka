import{c as t,e as m}from"./shared-SLDH6YK2.js";import{b as n}from"./shared-MABUIA22.js";function p(e){let o=n();return t(e,o)}function i(e,o,r){let c=n();return m(e,o,r,c)}export{p as a,i as b};
