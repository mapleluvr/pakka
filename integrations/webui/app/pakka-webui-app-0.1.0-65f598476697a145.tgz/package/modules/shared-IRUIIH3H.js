var e={duration:"200ms",easing:"cubic-bezier(0.42, 0, 0.58, 1)"};export{e as a};
