import{a as r}from"./shared-YF4EG2DK.js";import{b as l}from"./shared-ZE7MNSE4.js";function t(){l(r)}export{t as a};
