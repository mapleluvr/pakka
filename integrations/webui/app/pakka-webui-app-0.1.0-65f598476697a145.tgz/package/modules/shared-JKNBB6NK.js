import{b as t}from"./shared-PUAVMEVJ.js";import{a as n}from"./shared-AZS3U2MJ.js";import{b as e}from"./shared-DZSZYJLX.js";var o=e(n(),1);function i(){return(0,o.use)(t).locale}export{i as a};
