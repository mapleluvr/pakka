var r="astryx",a=r,e=r,s=r;function o(t){return`${a}-${t}`}function n(t){return`data-${e}-${t}`}function c(t){return`--${s}-${t}`}export{r as a,a as b,e as c,s as d,o as e,n as f,c as g};
