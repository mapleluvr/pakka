import{a}from"./shared-UVD54G57.js";import"./shared-YM5DI76V.js";import"./shared-DZSZYJLX.js";export{a as stackItem};
