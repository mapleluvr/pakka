function e(E){return E.isComposing===!0||E.keyCode===229}export{e as a};
