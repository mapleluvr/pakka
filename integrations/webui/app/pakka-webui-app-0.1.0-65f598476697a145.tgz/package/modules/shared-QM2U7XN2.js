import{a as t}from"./shared-AZS3U2MJ.js";import{b as o}from"./shared-DZSZYJLX.js";var e=o(t(),1),f=typeof window<"u"?e.useLayoutEffect:e.useEffect;export{f as a};
