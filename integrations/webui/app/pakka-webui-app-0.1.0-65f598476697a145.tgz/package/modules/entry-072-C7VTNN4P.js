import{a,b}from"./shared-DHF5T7ME.js";import"./shared-YM5DI76V.js";import"./shared-DZSZYJLX.js";export{a as EDGE_COMP_ATTR,b as edgeCompSlot};
