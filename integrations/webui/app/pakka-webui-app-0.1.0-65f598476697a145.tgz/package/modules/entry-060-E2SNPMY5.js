import{a}from"./shared-WTP5GT5Q.js";import"./shared-YM5DI76V.js";import"./shared-DZSZYJLX.js";export{a as indicatorScope};
