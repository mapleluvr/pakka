import{a as t,b as m}from"./shared-DZSZYJLX.js";var o=t(e=>{"use strict";var u=Symbol.for("react.fragment");e.Fragment=u;e.jsxDEV=void 0});var i=t((c,s)=>{"use strict";s.exports=o()});var r=m(i()),n=r.default,{Fragment:p,jsxDEV:x}=r.default;export{p as Fragment,n as default,x as jsxDEV};
/*! Bundled license information:

react/cjs/react-jsx-dev-runtime.production.js:
  (**
   * @license React
   * react-jsx-dev-runtime.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)
*/
