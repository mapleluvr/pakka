function o(...r){return e=>{for(let n of r)if(n?.(e),e.defaultPrevented)return}}export{o as a};
