import{a}from"./shared-NPEGICQD.js";import"./shared-YM5DI76V.js";import"./shared-DZSZYJLX.js";export{a as touchHitAreaStyles};
