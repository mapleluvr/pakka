import{a as t}from"./shared-UNWTQGQX.js";var e=t("TooltipPresentInterestContext",1,null);e.displayName="TooltipPresentInterestContext";export{e as a};
