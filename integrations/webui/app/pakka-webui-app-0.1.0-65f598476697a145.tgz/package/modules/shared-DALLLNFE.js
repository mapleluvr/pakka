import{b as t}from"./shared-PUAVMEVJ.js";import{a as i}from"./shared-AZS3U2MJ.js";import{b as o}from"./shared-DZSZYJLX.js";var n=o(i(),1);function c(){return(0,n.use)(t).direction}export{c as a};
