var s={fits:{kFalU9:"x1j4r261",$$css:!0},scrolls:{kFalU9:"xge0x1e",kZeWKH:"xish69e",$$css:!0}};export{s as a};
