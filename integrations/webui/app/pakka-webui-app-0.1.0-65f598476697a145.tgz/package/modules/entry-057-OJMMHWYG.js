import{a,b}from"./shared-6A7JIEYT.js";import"./shared-YM5DI76V.js";import"./shared-DZSZYJLX.js";export{b as iconBoxSizeStyles,a as iconSizeStyles};
