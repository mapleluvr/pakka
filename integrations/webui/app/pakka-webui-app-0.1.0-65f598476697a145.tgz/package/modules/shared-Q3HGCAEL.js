import{a as t}from"./shared-U2CDP4ZO.js";var o=t("FormLayoutContext",1,{direction:"vertical"});o.displayName="FormLayoutContext";export{o as a};
