function p(e,r){return{type:"percent",value:e,...r}}export{p as a};
