import{a}from"./shared-MKIST7TF.js";import"./shared-YM5DI76V.js";import"./shared-DZSZYJLX.js";export{a as indicatorPressScope};
