import{b as t}from"./shared-BSWJNCTU.js";function o({href:n,onClick:r,isDisabled:l=!1}){let e=t();return n!=null&&!l?"link":r!=null?"button":e??"inert"}export{o as a};
