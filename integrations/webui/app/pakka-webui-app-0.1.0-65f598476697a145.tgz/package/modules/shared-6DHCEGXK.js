var o="data-astryx-layer-root",r={[o]:""};function e(t){return t.closest(`[${o}]`)}function s(t){return t.hasAttribute(o)}export{r as a,e as b,s as c};
