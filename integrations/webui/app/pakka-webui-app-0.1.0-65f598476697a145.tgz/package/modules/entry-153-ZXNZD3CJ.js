import{a as o}from"./shared-OLFJOQW5.js";import"./shared-DZSZYJLX.js";export{o as setScrollAnchoringOff};
